module.exports={
    mongoURI:'mongodb://brad:Yahoo123_@ds031203.mlab.com:31203/vidjot-prod',
    googleClientID:'733951171322-9egqm7j2eblslmlspa616jdn136p6ueo.apps.googleusercontent.com',
    googleClientSecret:'7ALqvqd5Tc3kG8KTGEJWXRmW'
};